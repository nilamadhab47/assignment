import React from 'react'

const Forgetpassword = () => {
  return (
    <div>Forgetpassword</div>
  )
}

export default Forgetpassword